export const environment = {
    production: true,
    url: 'http://localhost:4000'
};