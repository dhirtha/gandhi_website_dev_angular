
export class FilterBy
{
    key:string;
    value:string;
    
    constructor(k1:string, v1:string)
    {
        this.key=k1;   
        this.value=v1;   
    }
}