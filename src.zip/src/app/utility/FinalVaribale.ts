//import {Injectable} from '@angular/core';
//
//@Injectable()
//export class FinalVaribale {
//
//    _favorites: string[] = [];
//    HAS_LOGGED_IN = 'hasLoggedIn';
//    HAS_SEEN_TUTORIAL = 'hasSeenTutorial';
//    SESSION_USER_LOGIN_DATA = 'sessionUserLoginData';
//    SESSION_USER_KEY = 'key';
//    LOGINTYPE_ADMIN = "ADMIN";
//    LOGINTYPE_HO = "HO";
//    LOGINTYPE_ZONE = "ZONE";
//    LOGINTYPE_CIRCLE = "CIRCLE";
//    LOGINTYPE_DIV = "DIV";
//    LOGINTYPE_SUBSTATION = "SUBSTAION";
//    SESSION_LOGIN_AS = 'loginAs';
//
//    //App level Data/// 
//    SLASH = '/'
//    FIRE_JSON_METER_DATA = '/Meter_Data';
//    FIRE_JSON_SIGN_UP = '/Sign_Up';
//    FIRE_JASON_SEARCH_CRITERIA = '/SearchCriteriaMst'
//    FIRE_JSON_CUSTOMER_MASTER = '/CustMst';
//    FIRE_JSON_EMPLOYEE_MASTER = '/EmpMst';
//    FIRE_JSON_ORDER_MASTER = '/OrderMst';
//    FIRE_JSON_SALE_MST = '/SaleMst';
//    FIRE_JSON_SALE_PAYMENT_MST = '/SalePaymentMst';
//    FIRE_JSON_ID_GEN_MST = '/IdMst';
//    FIRE_JSON_PRODUCT_MST = '/ProductMst';
//    FIRE_JSON_PRODUCTTYPE_MST = '/prodctTypeMst';
//    FIRE_JSON_MEASURMENT_MST = '/MeasurementMst';
//    FIRE_JSON_ORDERPAYMENT_MST = '/OrderPaymentMst';
//    FIRE_JSON_FAVORITE_MST = '/FavoriteMst';
//    FIRE_JSON_TOKEN = '/Token';
//    FIRE_JSON_ORDERNO = '/orderNo';
//    FIRE_JSON_CHANGEADDRESS = '/ChangeAddress';
//    static FIRE_DEMO = 'signup';
//    static FIRE_USER = 'USER';
//
//    /// users OF app//
//    static FIRE_HO_DOC = 'VM_HO_DOC';
//    static FIRE_ZONE_DOC = 'VM_ZONE_DOC';
//    static FIRE_CIRCLE_DOC = 'VM_CIRCLE_DOC';
//    static FIRE_DIVISION_DOC = 'VM_DIVISION_DOC';
//    static FIRE_SUBSTATION_DOC = 'VM_SUBSTATION_DOC';
//    static FIRE_MODULE = 'VM_MODULE_DOC';
//    static FIRE_MODULE_STATUS = 'VM_MODULE_STATUS_DOC';
//    static FIRE_MODULE_PROPERTY = 'VM_MODULE_PROPERTY_DOC';
//    static FIRE_MODULE_TYPE = 'VM_MODULE_TYPE_DOC';
//    static FIRE_SUB_MODULE_TYPE = 'MODULE_TYPE';
//    static FIRE_METER_DOC = 'METER_DOC';
//    static FIRE_METER_DOC_SUB_METERS = 'METERS';
//    static FIRE_KVA_INFO = 'KVA_DOC';
//    static FIRE_SUBSTATIONTYPE_DOC = 'VM_SUBSTATION_TYPE_DOC';
//    static FIRE_ASSIGNSUBSTAIONMODULE_DOC = 'VM_ASSIGNSUBSTAIONMODULE_DOC';
//    static FIRE_VM_MODULE_ASSIGN_DOC = 'VM_MODULE_ASSIGN_DOC';
//    static LOGIN_TYPE_SUBSTATION = "STATION";
//    static LOGIN_TYPE_DIV = "DIV";
//    static LOGIN_TYPE_CIRCLE = "CIRCLE";
//    static LOGIN_TYPE_ZONE = "ZONE";
//    static LOGIN_TYPE_HO = "HO";
//
//    //Images storage 
//    static FIRE_IMAGE_SUBSTATION = 'SUBSTAION_IMG/';
//
//    //STATES
//    static FIRE_STATUS_TYPE_DEFUNCT = 'true';
//    static FIRE_IMAGE_ICONS_HO = "assets/img/ho.png";
//    static FIRE_IMAGE_ICONS_ZONE = "assets/img/ho.png";
//    static FIRE_IMAGE_ICONS_CIRCLE = "assets/img/circle.png";
//    static FIRE_IMAGE_ICONS_DIVISION = "assets/img/div.png";
//    static FIRE_IMAGE_ICONS_SUBSTATION = "assets/img/station.png";
//}
