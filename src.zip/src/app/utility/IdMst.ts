//import {Injectable} from '@angular/core';
//Injectable();
//
//
//export class IdMst {
////    $key: string;
//    max: number;
//    prefix: string;
//
//
//    // reg_date: string;
//}