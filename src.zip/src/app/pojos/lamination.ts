export class LaminationMst
{
    id:string;
    orgId:string;
    oprId:string;
    crTdBy:string;
    crDt:Date;
    mdDt:Date;
    defaunt:boolean = false;
    lamination:string;
    vendor:string;
    paperType:string;
    purchaseRate:string;
    rateUnit:string;
    gsm:string;
    rateperUnit:string;
    rateLabel:string;
}