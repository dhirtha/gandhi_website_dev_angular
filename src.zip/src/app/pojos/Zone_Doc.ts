/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


export class Zone_Doc{
    
    key: any;
    ho_Key: string;
    zone_doc_zoneName: string;
    zone_doc_authorityName: string;
    zone_doc_contact: string;
    zone_doc_email: string;
    zone_doc_password: string;
    zone_doc_designation: string;
    zone_doc_type: string;
    zone_doc_reg_date: Date;
    zone_doc_active:boolean;
    zone_doc_image:boolean;
    zone_doc_address:boolean;
    zone_doc_officeContact:boolean;
    
}
