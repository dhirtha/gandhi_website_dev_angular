export class GstMst{
    
    id : string;
    
    orgId : string;
    oprId : string;
    
    gstName : string;
    gstPerc : number;
    
    defunct : boolean;
     
}