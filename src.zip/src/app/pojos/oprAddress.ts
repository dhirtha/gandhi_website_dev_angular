export class Address{
    id: string;
   addAppartmentName:string; 
   addStreetName:string; 
   addAreaName:string; 
   addLandmarkName:string; //optional
   addPincode:string; 
   addCountry:string; 
   addState:string; 
   addCity:string; 
   addGeolocation:string;
}


