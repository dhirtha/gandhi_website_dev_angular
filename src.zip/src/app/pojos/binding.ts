export class BindMst
{
    ppressbindMinSheet: string;
    ppressbindMaxSheet: string;
    ppressbindRateFactor: string;
    ppressbindMinCharge: string;
    ppressRateUnit: string;
    ppressRperUt: string;
    ppressRateLabel: string;
    ppressRLPercentage: string;
    ppressRLNewRate: string;
}


