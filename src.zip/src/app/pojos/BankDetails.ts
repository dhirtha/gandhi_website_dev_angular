export class BankDetails {
    id: string;
    ifsc: string;
    bankName: string;
    bdAccountHolderName: string;
    bdAccountNumber: string;
}


