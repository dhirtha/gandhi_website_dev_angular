export class RateLable{
    
    rateLabelId:string;
    
    rateLabelMod:string;
    rateLabelPer:number;
    rateAsLable:number;
    rateAsLableWithClipLaganaCharge:number;
    
    rateLabelWithLamMod:string;
    rateLabelWithLamPer:string;
    rateAsLableWithLam:string;
    
    calBlckRateLblMod:string;
    calBlckRateLblPer:number;
    calBlckRateAsLbl:number;
    
    calWhiteRateLblMod:string;
    calWhiteRateLblPer:number;
    calWhiteRateAsLbl:number;
    
    calSilverRateLblMod:string;
    calSilverRateLblPer:number;
    calSilverRateAsLbl:number;
    
    calGoldenRateLblMod:string;
    calGoldenRateLblPer:number;
    calGoldenRateAsLbl:number;
    
    die_IMPORTED_RateLblMod:string;
    die_IMPORTED_RateLblPer:number;
    die_IMPORTED_RateAsLbl:number;
    
    die_LAZER_RateLblMod:string;
    die_LAZER_RateLblPer:number;
    die_LAZER_RateAsLbl:number;
    
    die_NORMAL_RateLblMod:string;
    die_NORMAL_RateLblPer:number;
    die_NORMAL_RateAsLbl:number;
    
}