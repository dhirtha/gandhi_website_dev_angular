export class Elements
{
    id: string;
    DynamicEleName: string;
    DynamicEleValue: string;
}


