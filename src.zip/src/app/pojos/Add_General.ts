export class  AdGenralHdrMst 
{
    id: string;
    orgId: string;
    adGenralTypeName: string;
    code: string;
    defaunt: boolean = false;
    discription: string;
    adDtlName: string;
}


