

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


export class ImageMst
{
    large : string
    medium : string
    small : string
    ex_small : string
}