export class StandardMst
{   
    id:string;
    orgId:string;
    oprId:string;
    crTdBy:string;
    crDt:Date;
    mdDt:Date;
    stdProduct: string;
    stdGsm: string;
    stdPrintSide: string;
    stdPrintColor: string;
    stdPostpress: string;
    stdPostpress1: string;
    stdDeldays: string;
    stdRateLabel: string;
    stdRLPercentage: string;
    stdRLNewRate: string;
    stdPaperType: string;
    stdProductSize: string;
    stdLamination: string;
    stdLamType: string;
    stdLamSide: string;
    stdQuantity: string;
    stdRate: string;
    stdUrgent: string;
    stdUrgentDel: string;
    stdUrgentRate: string;
    stdUrgentNRate: string;
//    stdLamination: string;
   
}


