/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
export class PaperRateMst
{
    id:string;
    orgId:string;
    oprId:string;
    crTdBy:string;
    crDt:Date;
    mdDt:Date;
    pratePaperType: string;
    prateMill: string;
    pratePurchaseRate: string;
    prateGsm: string;
    pratePaperSize: string;
    prateAvailabel: string;
    prateRateUnit: string;
    prateRateperUnit: string;
    prateRateLabel: string;
    prateRLPercentage: string;
    prateRLNewRate: string;
}

