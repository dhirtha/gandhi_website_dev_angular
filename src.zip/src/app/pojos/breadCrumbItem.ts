
export class BreadCrumbItem {
    Name: string;
    ShowOption: boolean;
    Id: string;
}