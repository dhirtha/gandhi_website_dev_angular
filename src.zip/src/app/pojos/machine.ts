import {Elements} from "./DyElements";

export class MachineMst
{   id:string;
    orgId:string;
    oprId:string;
    crTdBy:string;
    crDt:Date;
    mdDt:Date;
    McName: string;
    McType: string;
    McColor: string;
    McMaxColor: string;
    McMinLength: string;
    McMinBreadth: string;
    McMinSize: string;
    McMaxLength: string;
    McMaxBreadth: string;
    McMaxSize: string;
    McGripSize: string;
    McPlate: string;
    McDyElements: Elements = new Elements();
    
    
}


