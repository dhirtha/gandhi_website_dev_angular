export class PostpressMst
{
    id:string;
    orgId:string;
    oprId:string;
    crTdBy:string;
    crDt:Date;
    mdDt:Date;
    ppressActivity: string;
    ppressMinLength: string;
    ppressMinWidth: string;
    ppressMinSize: string;
    ppressMaxLength: string;
    ppressMaxWidth: string;
    ppressMaxSize: string;
    ppressChPerforation: string;
    ppressReqDt: string;
    ppressDelDt: string;
    ppressRateUnit: string;
    ppressRperUt: string;
    ppressRateLabel: string;
    ppressRLPercentage: string;
    ppressRLNewRate: string;
}


