export class GradeMst{
    id: string;
    orgId:string;
   gradeRole:string; 
   gradeName:string; 
   gradeKars:string; 
    
}

