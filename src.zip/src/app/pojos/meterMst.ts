export class MeterMst {
    key: string;
    subStationId: string;
    modBusId: string;
    meterId: string;
    meterName: string;
    ct: string;
    pt: string;
    KVA: string;
    hostIp: string;
}
