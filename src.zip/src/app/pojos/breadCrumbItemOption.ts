export const OPTION_NEW_FOLDER = 0;
export const OPTION_UPLOAD_FILES = 1;

export class BreadCrumbItemOption {
    Data:any;
    Name: string;
    Option: number;
}