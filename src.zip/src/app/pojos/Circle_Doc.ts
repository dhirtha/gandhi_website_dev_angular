/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


export class Circle_Doc{
    key: any;
    zone_Key: string;
    circle_doc_circleName: string;
    circle_doc_authorityName: string;
    circle_doc_contact: string;
    circle_doc_email: string;
    circle_doc_password: string;
    circle_doc_designation: string;
    circle_doc_type: string;
    circle_doc_reg_date: Date;
    circle_doc_active:boolean;
    circle_doc_image:boolean;
    circle_doc_address:boolean;
    circle_doc_officeContact:boolean;
    
}
