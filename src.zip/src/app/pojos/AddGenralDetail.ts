export class  AdGenralDtlMst 
{
    id: string;
    orgId: string;
    code: string;
    adHdrId: string;
    adDtlName: string;
    defaunt: boolean;
    discription: string;
//    defaunt: boolean = false;

}

export class AdColorMst
{
    id: string;
    orgId: string;
    colorName: string;
    colorSide: string;
    frontColorCount: string;
    backColorCount: string;
    defaunt: boolean;
}