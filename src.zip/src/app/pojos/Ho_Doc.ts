/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

export class Ho_Doc{
    key:any;
    ho_doc_stateName: string;
    ho_doc_companyName: string;
    ho_doc_authorityName: string;
    ho_doc_contact: string;
    ho_doc_email: string;
    ho_doc_password: string;
    ho_doc_designation: string;
    ho_doc_type: string;
    ho_doc_reg_date: Date;
    ho_doc_active:boolean;
    ho_doc_image:any;
    ho_doc_address:boolean;
    ho_doc_officeContact:boolean;
    
}

