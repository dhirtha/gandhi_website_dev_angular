/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


export class Division_Doc{
    
    key:any;
    zone_Key: string;
    circle_Key: string;
    division_doc_divisionName: string;
    division_doc_authorityName: string;
    division_doc_contact: string;
    division_doc_email: string;
    division_doc_password: string;
    division_doc_designation: string;
    division_doc_type: string;
    division_doc_reg_date: Date;
    division_doc_active:boolean;
    division_doc_image:boolean;
    division_doc_address:boolean;
    division_doc_officeContact:boolean;
    
}
