export class CutrateMst
{
    id:string;
    orgId:string;
    oprId:string;
    crTdBy:string;
    crDt:Date;
    mdDt:Date;
    cutMinUps: string;
    cutMinGsm: string;
    cutMaxUps: string;
    cutMaxGsm: string;
    cutRateUnit: string;
    cutMinCharge: string;
    cutRateperUnit: string;
    cutRateLabel: string;
    cutRLPercentage: string;
    cutRLNewRate: string;
}


